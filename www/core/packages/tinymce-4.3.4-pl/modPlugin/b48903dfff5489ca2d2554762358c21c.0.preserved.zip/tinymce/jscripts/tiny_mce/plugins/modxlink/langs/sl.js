tinyMCE.addI18n('sl.modxlink',{
    link_desc:"Insert/edit link"
});