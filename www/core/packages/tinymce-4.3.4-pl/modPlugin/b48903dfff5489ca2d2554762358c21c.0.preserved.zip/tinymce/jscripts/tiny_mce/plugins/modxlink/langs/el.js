tinyMCE.addI18n('el.modxlink',{
    link_desc:"Insert/edit link"
});