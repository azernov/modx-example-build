tinyMCE.addI18n('fa.modxlink',{
    link_desc:"Insert/edit link"
});