tinyMCE.addI18n('he.modxlink',{
    link_desc:"Insert/edit link"
});