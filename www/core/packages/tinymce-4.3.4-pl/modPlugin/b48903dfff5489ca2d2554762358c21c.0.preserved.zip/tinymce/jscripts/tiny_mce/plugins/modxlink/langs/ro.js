tinyMCE.addI18n('ro.modxlink',{
    link_desc:"Insert/edit link"
});