<?php
$hook->addError('name','Please use a real name.');
return false;
