<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '647230fe96062cd06f380bf0ceb2540d',
      'native_key' => 'core',
      'filename' => 'modNamespace/af3ab1cdc5ef489e2e09410ce4c8e047.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '51651b6b08b491b0e988cee39c26c634',
      'native_key' => 1,
      'filename' => 'modWorkspace/9020e4207c2aec02a446d0753f9b2a5c.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'ce862361711e7aa094014549f25bfbc8',
      'native_key' => 1,
      'filename' => 'modTransportProvider/b2767a9eb9c4a5660ed54a5e65f41c0c.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '94d35d22c793392a31be301a5832e5db',
      'native_key' => 'topnav',
      'filename' => 'modMenu/5b2db2a7caca11de9d8e4d1bbde74de5.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4d9aa9e580aad79b0c65c23ce0625979',
      'native_key' => 'usernav',
      'filename' => 'modMenu/3c5c53aceeae0feb4a91c2da82a0bdd8.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2db7b5f19a82871a64cb116f40a1ccd7',
      'native_key' => 1,
      'filename' => 'modContentType/a19b8bf49c9f93a0ca17926d9755ea65.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e858dedea3627fad9fefc1ca5ea4e2a7',
      'native_key' => 2,
      'filename' => 'modContentType/eb863b8b00f6e9ea043e7aec8f9dbf51.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e2700c17e548d5f8d5cfbd4d96394ba2',
      'native_key' => 3,
      'filename' => 'modContentType/ee63099535db248362aede6960562842.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2b1cf58af55e4b7ae48f8f5d16279c89',
      'native_key' => 4,
      'filename' => 'modContentType/0683ec72d4b16603842f783648b7eccf.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1b1423d19c062d1028e7a3d38af139a1',
      'native_key' => 5,
      'filename' => 'modContentType/494ca5666138d1a004f35fadf7f7d400.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '188c22832361fdbd2bfbe7d5e9473e39',
      'native_key' => 6,
      'filename' => 'modContentType/8e80e3033b298672b56cb629dc0a366a.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'acd4394e05f1322568ff9b880779d2f4',
      'native_key' => 7,
      'filename' => 'modContentType/a63543dfd89cabef89a54262d57fe554.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '599f0aad994305290c300ef09a3de38e',
      'native_key' => 8,
      'filename' => 'modContentType/d0ef9fb3db01fb9941121cd6376eafd5.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '584c9d53349f39ab5d7abd7ffcf96130',
      'native_key' => NULL,
      'filename' => 'modClassMap/9bbfe41bf64ed752dfdb1574fc02dba3.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a3752c9e4dfca78619598c6035846a70',
      'native_key' => NULL,
      'filename' => 'modClassMap/56c0d460394f56422a37269f796a1f17.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '50e6998aa2f6bf9889f17573e44deb57',
      'native_key' => NULL,
      'filename' => 'modClassMap/6cd725452cdd290268b7568a4daa86e9.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '69f8efe87b73853fe8eca209112fab57',
      'native_key' => NULL,
      'filename' => 'modClassMap/895820722894eb80589e312a0baff4ee.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3447589e4f579dc05e84c027e35f074e',
      'native_key' => NULL,
      'filename' => 'modClassMap/a6017279ac44d191e4a20a89e03aefe2.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '788f38efdb830cedc043b7036c5e27a2',
      'native_key' => NULL,
      'filename' => 'modClassMap/5750022b04611fa3fb5f57d0671df830.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e3fc85e3e2f61e0d13b78e2912c7e335',
      'native_key' => NULL,
      'filename' => 'modClassMap/107ba08e8b5ad1bf26bcf8e25c5f83f2.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e9c415b9cba41bba3b1dacded4408b72',
      'native_key' => NULL,
      'filename' => 'modClassMap/7359c8e2101611ad52ba73b7b29f6f18.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f02eb33aab73e5cc0574430343634d68',
      'native_key' => NULL,
      'filename' => 'modClassMap/e87a21bb00adb2319bb2ac899a84405a.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0202b4f42bd077d9aa57f690163e2992',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/ddb56f269137072a5f6f88dc377060df.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9219e5d4df142d0ae81064d70f6464c3',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/d4a717690bf752c458ce4cd269513fc9.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb69ca93529984cc26a1b3c18189f1dd',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/4d8c14c006873c49aa02de21ddd5144b.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b86394ec1242a2edc75df65584dfdbe3',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/ec5e5ec557ceb965b9640c8f4ec4e78d.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9798f56f1e82a1d079234370b647fb8',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/57db42fac4db221e92b4f0cdef3b0142.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73e386f53b800beaf8a79b1b8bf48a40',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/248ac2f0af5653e8bfd7fd5d6d7a0346.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8525111affa39d556c81697e968e6ca',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/03d387d49d97bed06a706748620075a4.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebc8312e040f18e100471f7f429318d2',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/e8d8dd23ca248260a11d5cf853dc087d.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4417e27fe9919fd5c033e626db2256b',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/41ba2a754e6b849fef37d6f061780247.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c0554f34970a14c087ab93f0de29ba7',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/f76dae6a609215d404fc27e7de01c0bb.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a44f137481af4b79bf151038963e309',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/96f8a3495bd2ca4db80ddfc3cf932999.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9778569eec69959cb1e4a3a972c4864f',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/c90a23a27c598919b809bdb83f42348d.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'addaa9d27363322717e7cd4ad7139312',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/957a737e8fdad34e88b27675c651239b.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2f8fafcb9cbe7dfb0b733fcfd1754b6',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/4fe75f90a63e7650c710ec5642c82983.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec212a8632944fefcd9ed8ebcd9fe278',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/6f9243ce5e57047ee8f1202cb6f58650.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a5230b19cfa15b077b4bcb6ec0029f4',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/8626bff36e3e30a72e4947fb4c5b6104.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa4e6fee881398283dc5be2f985881cc',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/4edd1d52d1a5ae709ffda3dafbe7a2c3.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34d7ed1f533c9e4cd3ba614803d693ab',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/339a12ec4354609ce6cd0fe609262df2.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4ac6e573dd5c1c2cc40ef08b6f7b02c',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/677be4040dc5a5d6c7e3bac79b83c886.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2077fe9ccdd655820fc31c338a30c18a',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/b77e0ee64b5fbcde0be710acc9b382e1.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3aec4a729e624b6cbd2a90fe20cf611f',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/d172fd11ea4a03d56b0a84517ee1b66d.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd4a6c4f396af0aed690c4a6053cb8ed',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/86953b47ad2071ec69e1dbf4cbd68eb9.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ac9784124d9b0b8516f9c866f4ff9c7',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/483b4b0051121bf3c85f3aa8eae222c3.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49a130fba55c5b55b10854446027458b',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/36901adf51c40096df0cffa822e28acf.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f406a8c354b10d228a9515732949484',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/01b8fbff6c3dbad539ee1cb981da37b0.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d0f2857cbf08951344428fa7566d407',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/6fa9e2c9cec4ac58f1f34e97506cf21d.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53b3aca5899380143d42efcca17d3760',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/33f3c19778238cc9ebafe0b7ca8a2d10.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97a963d1e199515baf53e4c4f497e4d5',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/0f54f3058eb2bb6d48ee0620b5a0e534.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '556ef60873fe345610fbc21567a90823',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/d73efe2b342a178f26207c7849fd5847.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4816715bf02f163a85818fcdf62dcc1e',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/6e524837cf2063eadd8c3ec1e85e62c7.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84bf93786271c50ae2e657489a72c166',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/7717db141001754ed04d63f93245c041.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa527c446d8857c4b2e06efbd3214cd2',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/0639dc22050b1b9c4358237c768b946f.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c559b134e8179f6b0f0e73209bdb9a1',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/c3c927280afec8c7c95545dd48dab8ec.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a9e6e8b3eb4e4d34b90ccbc48b0e179',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/4b4940478f57eb2e38633a40ee14ff94.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9109bb5317dd5ee49ca1e32f2ffcc215',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/2355384bc8224788de9c530389cb6253.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be038fd41c980a7ebc3a8cdfb3af4bb1',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/b7a9892f47a56bfb73be930013c205d2.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08e3ec160233f0e59f3668bff977d37b',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/f7e8ed873469424e7dad6dd9a4c8654c.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f146fcb549b9fe769b69e88ae58661f8',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/abe6558bf64260c852b4fd92dc925470.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e37c39b027e9fb0f0aeacc8bdb304e2f',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/51bcd617c5e9975874527c560d1905e5.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6876aee3e2de5c5bc3141b6f0bc0ca61',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/6b0023547ddb0075375c614f5b3c9820.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '634b4ee2b4784dccc569a868f9bbc0af',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/9820376bbaff1c993b8867973b34f83d.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7b01b0bab6b302fbbfa0c99101fa86f',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/9cba916e3223447f0fca4be01f5e6b1d.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6407b1352357736d39622035e76b3c31',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/1ed4cdb3094876ceaad276bd072a8dd9.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20accb4b26e8450cdb290cc61ffdae1a',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/65110309307a6b4bbb9d17c55b013503.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '305e4034156d728046980d9ae00333a8',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/0cdc6765f91cbd273109f7f27ef81986.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46e10744e2edb99d1f403dac6a8f8149',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/b02c75e3cb9750bf69e159a8f99a561b.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbbf992e739e302f449edc1d91a6be49',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/dc98ebd9e86ef5fed28bdc672f582c09.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66fea76088afc4fdbf6707558cd6d8e2',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/a05ed569ebd476bb3da8ea437a72738a.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27ead3acabe8bc07e60f41bd7f3bf5e3',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/cfe748c1bcb15cab1c4289030a9a5032.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d2b0823366b2c4d96275aeda15b754d',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/8d8b3ac80cfb18a31e14975f69472239.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31b0a5d1bbc5d8149eda032adfdce14c',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/73caa586d8818c6ce985340d6a6e4065.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76bd238d47cb537519a67c74a0ebbde2',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/0687591f143561cdf2a034767f8e05d4.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17495f419372bcdc5b6a69f24d011fb8',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/244f5332a5c61353190fa06cb6a87ad9.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46322d38c9a9920aa7c6ae8b2433412b',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/13c0b91965309366d16c1354d07c3a76.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4dabf6019421ca189c7fee22e4934c83',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/08e996330f38744c06dec68630e348e4.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '209568b566acda9a1d6711049fe04b26',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/dc020fdd2df41926540acbf060f36d5c.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '299f4feec41422b2ce1e47e9a91c6fb2',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/3c05145caa510eb558d87ed7f4ddbee3.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd35329471260d8756767f18c754167a7',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/600601edfebe5b0744a5a3c8afcd59e5.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ab0325dd5be76ed6ebe003176283679',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/6dfd0ebac00ef3402da0eda37c2b0780.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84da83a1ded6e4a1ce9281ae3e0de22b',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/b42ae6cea57c197b7b9feb3eb97830bd.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6844437d841c6cd9443b97ca1a4e25c0',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/6e4da4aabe2a96ef9a2297cd47df2c56.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a21d5588c64560d079cb4ffde608ca40',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/a9e57ba98460591c36297e6602b6af88.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f9a123632c5a019fa49a2dde0b3b4b2',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/cf696a7bbc5938b5cca1c828fef9e96a.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7de1aea5b9c9625ca44e55df768bee5',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/70725c7d7bbc14619412ef22d9608d45.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6799ae23aac1eec94c684cde467201f5',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/a6233a4d7925f809ef1011c5e010a002.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8dab45184b7c5bd65b1f49ab3f9ae26',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/54ab9f178fa44e89e43b59628619e267.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e9d069ac557bab4b61d97a44e68cef2',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/1af77235b0cf7f1151d36c7a2776cf00.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96c82daeed136beab540fd31ca028d5e',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/f03d0de6650d95cf8051d3508f1f875a.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72fa89af786f7a827d282421dd1b2315',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/3eb480bd0f05603b1f0e2aef2cda6349.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4277c9a336def7c221a4c5465628f3c',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/37cd15375f2061cdea69e0ef31a0b891.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9bff348b7b292f50e0158879c2743c6b',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/b18f3c109628ee774aeed057303e8624.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b0531ce0bdb92d36981c79af232dc9b',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/f5b324cfe9b67a8fecbbd5cc9b948622.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abde1bbe7afad47e412021cdecef7f3a',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/1ac854e9660419f7e33369a88877264e.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3da0554ca7b8c44e28edc2b2c4c1cf8',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/72174bb09d8c96962c583217d58ee528.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cddc92c922c87c3ca89e91b93c17d4a7',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/78f5701a52ac0da21e78e324d87297ce.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ee0a9eff25704a7b804600769fd34e4',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/c7a47f0b1482ff11518a21f7afaea4c0.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8244779cf5c65313fbfc2bd7fe5aa83',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/b6499af5bc1f63d7123467ba4ed5c331.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '285097197876525762ed329b93c67e13',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/07193ff9075bdd1504eec01a33be7c8a.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26da4e0bb9373ffa768184a36c48dc43',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/ce167ed8a53e6b113f5c1783e7743c26.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cc3398753775ff79f062649f16dea60',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/7075a569d025083d50321cda6fed86b9.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d94528066e028820eb8970154829260',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/ec113f39a47feab55701199e80960daf.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b95e75adc1398ade27ca925b8be4ac4d',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/ee00663b118a03042625dce90ae17fc9.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e65b0ccfaf0d0be5db131ac57cd24819',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/a72a7eeb4d0437ff953eaa11c0b21691.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d9edb5e7745f685a8b3feeedee7bba6',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/070096480bb927175eb46fba086e87f7.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '014a26f0ff6779e57fc061f25048779b',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/b80d44b78f9fda9bb90ee1490d2f64c2.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54aa3c1656d2b0151b8267710283c32a',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/400276e2e850b590d4cd8cfa79018c29.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f71dcb141c36b1b679338fac0f40ebc2',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/b9f14b86bd7d461b66cfa36cc76ec5a5.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9731b23f5b12f6b7d7712e2ba2ee870',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/a77cfa69aac60b1e779aeeeaecce9bee.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '368dc3a296b79b2ac123ef4c7630bdf4',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/dbade92508669d483f951e074f7b2577.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '743ed3105e1ca57451f419f77d901bcf',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/9f67e2d53bbf8302bfb2235563dd44cc.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '135d21f879ac24d6c54bb864b3052748',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/5137ced01b53fc5abc9ac664383a029d.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0cf3c7b64020f4c33cbf58bf8c746767',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/492dfcc1ffff3c0ff690f56f7b3f6307.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a849a212fe19f49e4f55130e5c2337b',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/788e8e9653eba27ee7c4a9c7452a246e.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5274ea636681d101b64a99018bcae59',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/9950bffb9f5de2eb90774489f2b8e34c.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71737d9942461fc3cd7515a190b91686',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/f9e90da8f1f71c35255368b226d7970a.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8bd2eaecbbd52d04c84d1a7883faa7f0',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/0d29ae6ebe8c623a127a0cd46e5498e3.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '473f47808ae35fbebe8c9b79f34dfd34',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/d0bddd7ce1ce9af8d58708d08e304867.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2840b9a74e5ef344b77c5a4557a20700',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/ce65bc0b1e05b9ff06b42028b3320529.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75a1cb2916a755bdbc9ad4f2a440ee8e',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/9cea08bb9578f527a44d9f01d2ed02ca.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec2b6e72f0c65263ea8b43d22065fd7b',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/eb1d9c097a5618b2bde5808d386622f0.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '563457868125ac4184f4093c11c10190',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/8b058684eaaa97e6adb6b0d0670def87.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '226fb1db2031c48469cd942e3a61a223',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/487a8d972a8b1a2427769216cd9e2fb3.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9afeddac3c79e9cb5b4c1c919bfb5f5',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/b109aaa0356dae2481505e87c388e880.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a938badd5f12494314afaa5069189771',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/c3e95f155257a63d822f733b45702306.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b4c0a016e42d01b2b0c58848bcd37a0',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/e633149a07476c0326264c6c0727218c.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1236e988348823625470ff8a2ffdadf0',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/b7fe514960e740ce29ff6feb7dcbe91f.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '968b8918243bd19f79d4f4cefa8d3a3b',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/c26872f261538ec6fdce5e8bfeca63c1.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6c81f5a14362da9707c14a5bea7c4e5',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/57a410e8ce01a8e2f254b2babcb96021.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b5215e4b9ef6a0b4a074df0aa7c3e23',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/33a608abcb58e973e22e2a8e990f820c.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e9024f34d23ab612a98e982d4c3a4f1',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/04ffc03441aa451788993d86afce52bf.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '874a05a6a685a0e91d2c51d9e03cb287',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/118a9e22d78085dba3a65e8bbc98c567.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90fd3cfd92fa4e3a217abe356eb63185',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/78012bc0f8dcc39d7ea2fbc00ef32007.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a98472f33ca87b023c2b312f93ef8d5',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/f7d6144ec4ba2feaededd635bb840149.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e10fb3456a98c23bb86f83324ad24006',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/8c279eca28684a510a01c9319e4b3241.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c5cf9db2484306f146a6bddcc36362a',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/f88e6bf9bbe5ea3bb30c245a0d244f87.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9ebc2d9c7e87b6b7b3bf10f2faeb527',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/ccca4f3b183275c52401b17348d97df5.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f1bc5346ec939be2c043c6a6435d5b5',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/5abf4278d98b16eb4c0ae158f844b17a.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5fd568a5037601f5d07d24a7fd06acd',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/d5b8e1f5e98b17ea8bc3245e97ed8bad.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b019c4bc8957b57b262baebaef371eb6',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/764256274eccbbbc0ecb1d19c24f9f31.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a0d7ccd2f3d760018f11daae2e5f8dc',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/ee1a777fb75c9d52d908dea71833c278.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce99cf543ff7a860d90c77288d18dfdc',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/3da57a7a99fe0380cbaa77a105d72938.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f5fb1e23399372c9e89f144850caab2',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/06fee5a7614698470f26d14bc187f5fd.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e839af4539c2be5a9a990accc0c5af3',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/c19b57096a667f8bb851e3b52da2ad26.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4160d5cfea7d22a54519f45883e127c6',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/c0f50734fc66f0b3d9eec0086668f263.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5ed2b7ea36484f0bc3728fbf2cb261f',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/ace17838b452a6bb24330fcfdd3d51f5.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b76dd13329e27255c632b5f720fa2feb',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/82950be4a361a238f65d37a7d9d61853.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7871bcdea169a6deb6501d3a648b877d',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/c795fcdb9208607df0c4b454c69f5a98.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16987c3d60a989e608fdc04a05e6ba85',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/c60e4ed706cab58e8c5d6d3accaf7eee.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f42f404330abc9096fe083aef9d5c2cc',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/ae2b6d1c00da358ec6e20d1dddf947c0.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88b28b776a6d4d3ac5744ddbe9e23b31',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/065a48c7686f60124b66a952145e37e6.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a26b4ae0ebb0ba7aef1fc1410d532f4',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/34e136d6ed8ecd7d2ccab68189dfddf4.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff1a8d84b4b260cbf860ad5e0a2db339',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/6356079bfa88707ac0d8f78d8020df10.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef1b9b9f5045ba87f67400848cba237e',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/730ff88e22d8120db358d9d6ba6ec558.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ec7e604bdd9ffe2c83043454ac7c3dc',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/706c06ed8d1e9e4a7a8d0f9f8a044bbb.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b550c9370fc6a95a2f5eb547fe1674f',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/53af7a826189f73c59546b80868344f1.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbb9984bd81f3b5c584499f7c950e54f',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/680e230bd88f3943231150bcd64f70fb.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39872fee0ebc22f50f5a740771764bd3',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/c44cc7eb0311e45236464ebb6aadef72.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14ab67cb39e8c6dc0644da050531fab5',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/60f3e37adf2122327eb24347ade497a9.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff26810b75a7fa277ece20393c33db8e',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/c72e42be7232ab0501c2d3e531d3ad03.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb5e198c824da5e5e1916b6639de66a2',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/401f4b468643b62b4f8265fe6f3f5687.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc1c67b10e88eacf182235a0f5d51504',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/a651604a259b8a1df8bbad7f91e7d2b1.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d5caec66516fa7636cd6e4ff219f9ae',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/dca88149e150ef515db062ed6ab8e576.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9645503648c28d3ee645db042ba06c48',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/8a077af4d272e6f81cd8a607331636ed.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3067027327be04b05fc8a0d3603ecc24',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/a7571ae7f389070c1b38204e573580ca.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4644186f2057e3590f0821e6f9768ea3',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/a03a38923b2cd4dcbad833fc503fda90.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b47b8ff4c757b480a2f2b1668396546',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/a741b5fdec8ea89c804285fe1bad76fd.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c4942ea44a2b9ab71c894101fa9ea8a',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/0fa6ff78dc6b09837a5a868c907a64ae.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b77cd84e941ce1708ac30146991f103',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/44bc2af01e2b1bd8db24f4492eadaae0.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ebde1c35d067c4d34d06a8906af2d4f',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/a28bb3bc2d28553ec7728993a0cecbe6.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54391a6ccb1a0270b47b4de0f4f91ca5',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/6d4214eda0b3a10fd6b751a6813a25ba.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0ccec83d85bb0b9d5ba652737910df4',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/563ecfffb239973835db1be512940b72.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '008a45e417ef0a26e633772d6555bef9',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/e58da125e74ca9c86e440eb716ad9319.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2117d74ec18cc9360061fe933dfed96',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/0dad76a333b4fc7f4c65bef75b862ae8.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '524b4e29af57dc8f95a149de5c660e12',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/843ea6f4d786bce115069605bb3da1d0.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22b4526995dd1e56f066bb8a1d0e2d43',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/262de6800d7d713e5fe59c86b944c597.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1df248f6391b0d04f6649e25339d32d8',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/a4012747610b86a086854e58d9204318.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6774d76e2cd6b651a57b8c40fd3bba47',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/a3faaa51716f04e168fe57b15482222b.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03093770a1a6300d1309566f4f7ccddc',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/6791ae3f698462cdd9bf357aa5919bd9.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c350a6912b194305faa3331807c08ef',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/671189fb832b0dd1393e8af53d412881.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db66657f904a940e5c189b19adb6a120',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/df209bae401e15a70d407e0d3dbdc7f4.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '323706e58f89a7c81347cf57626a868b',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/a767b446c5afffceef7bcec196538b10.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8aad8dac54b78b20459feda718111dd',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/0304ac370ba69964a7146c470659fb48.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74c963536ba3faff322380110ff5826d',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/cff86d37a45a00fa39b1d24e3a433e13.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f15519efa497a1dcdaa178bd27369f71',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/61401dcdcd4526caa3752cf7f0eed1f2.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94cf50619109e12fae45d83349eb88de',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/b8100620c9cc6cfa95d021d6d7ad15ee.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0c210fe3fe1d3a7eb83d5ee33f1d6b1',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/a0120022c2029df3d7dcd7e6aa61233e.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d16c26a871b64f2a7728091d93f7b3b',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/d385e376b3308cda63b981dbd296ed5b.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c623aaab0536346884d98464269830bf',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/8a195e7c6a4b16059e32595017195a7e.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afa97c7ee291bc5267a11a25cbb11d39',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/a77d5d7b973272c66bdef3f59fd3b29d.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0a53736f0bbf7fd978844f875821baf',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/209c004d0750fc32b39c096716e4dd2b.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc39a95782927c0521d28966aca5965d',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/5ecb5e76a898c3212c2597d1c042de0b.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7de830fbe9eaf4bef5a12c4483eb531',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/af2e7b6ca2eaae33f36e66028fbb8fd4.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afed113cff6e0e1a3b01b08735afcb63',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/179ac231c2eca9b5721baccd2173913b.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26e3ec6cc03dd817583cb1b7f032f0e1',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/ff9c3d96c550df7fe60c9834c299bbc6.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '752a99cad6d2f0e701a5c140500e431c',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/0497c516f9ee098af16ab384b72c7679.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17a8fb795f56e2c1a83e39d1d00fcf45',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/d5cc73628956a8bf2c4b6471a50232eb.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc1296b332c5f6af9f602e0512ede280',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/9862d7b04f56fda318f2e9d389e86d46.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aae38dc9d71a12dd9a2c1e4ad839c932',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/382a66206dc834c5e7c04d9d04d89bd1.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7faced27d900638239e896336d530d7e',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/214379e7f2ca4dccd1bb19e4d0dda1d8.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1675eeb13a583c1b2e15544b2386db2a',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/0e3d965b322baf6ed752c914c8109ef5.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7f8c55f96c202bf05e65b79eee5a8ff',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/cfd870771901c07a2473e08cf8affef2.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccedc25ec5ad3fcff7487fb7d5224d62',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/a493e5d41f2bc61d656f9262713f75f1.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d15aaed865dda0ea39302e579cbdb91',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/7f1c8d8ea67a538955d91f0b921307fd.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3452f84902025fb1844a303438de38a9',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/f572e89d148209aeb9dd6b826cc6846f.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc2dd6b4b5dedefb187c0fa7f2e6c515',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/bd62b9da2198b66b43fd2be499f1bcea.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fcc80239455add0f0a7b12c4a16f057',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/4e362c5d76b0890440cc2549479aff0e.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fda30692de37e623379214739c793ffa',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/698c76d1ea1fb73b060a143031d630f3.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0c3d5dd6fe3f99dfc9b767bc00d1261',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/5d020b128615b5714cff5e588e4967ca.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5a42f6acef5986828482178bc84c36c',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/94aea5ff16f9747a0e7a3a252fe54029.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '935dab739dc2d03d152d17d193fd92ad',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/17c82f1f1bf187408cc20b726e975bfc.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86062ac27b6975751844b4e4f33d6176',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/a42471fcf5557ca63a0a7e1efbbb7738.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c21254e4f3fe90ecadf8a5e8afcf82c',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/86f822a56386cb0a31b8c3b6feadec79.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7b402708429e11747091b6204036a61',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/4e16937b076d24961c92d205d2358f3d.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25b7c1d4b026568fac11fd5faab6172e',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/20d6e47da8a7ab6e6ccec53e941adc02.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e47ab8966be0e037bf539438c2e8d2e',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/837981882236f78a84299c66bc2fdb51.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '267f66d5c9df2ebb1fbf2d0965e7a8ba',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/69dba4fbc01f2c8e6804b519d8ad68c0.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ba44530ace4532ac252d579e63bfacb',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/8f1e769cdf4a692f8ccf995c672eda15.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '442515a928886f097c509ed8c9bc2555',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/9fa9dd3916ec1b045b3696eb0deb94a6.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10628894838ed253e9d01afb285335c4',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/436ea9e76b79706b9f03de739e91d620.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3408c26e0f5b006340cc22d23c1de5c',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/5fb60b9fabf8efcea0e46ec0d2ab856c.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1a7766d954171feb4b680a6d6fe7515',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/b1fd2bf7a982a6485abe53afed5534df.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efb76c5c3f3c34fc9ed615d73bc72308',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/121bfe2e79cb93d89a3e5915007402bb.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae0be5aee72838050a0f76a7eb626c29',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/90cc7df91a004232ecf6c2483595ff37.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b4bf5d1143a63996a3764d37eea9c10',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/59de42d2c23963855a524021a90e6cbe.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30df82ca021f61b54fb4e03504707a9b',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/8c226ee51b885a007984236f537f45eb.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efd172ddcfcf75453b6c6a611170bbf2',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/87ae12ccf53bdd694dbf4f9c0cc5f1fe.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5eb9cef0b35a6c0f9ef418a87d9061bc',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/439e02216ced246c4897eebc7b0fb106.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff12e1b219e6af8b223fed21bef56d69',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/856798a39ceda0282f665def11c04d06.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87e873db3673dac4c8821ad5571b338e',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/6be1053050cc120fa6ebd5d6667cc7a5.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95f86080dc620e2f663cae86acdc790d',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/50c5e0e46437f57ab02b87d941af1283.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '619874e1c2b9d942d1db99fddb93d41e',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/d1f5738525cfafa3debb063a365022e0.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abb51bbd87165b5c893e394b55ec5ad5',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/797ff7c0579bfcac8c96dca9d185e491.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8779f5a2a00006a7f663ca565904f31',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/543e2e8fba2cbecf40812427210823d5.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b3ce5567bf1c7b37e46b862ebeb08f4',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/683a90387e63253ab30c02188ecae2d4.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90b77eb0142ff7b3aabd948ea1d36d4b',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/2229388f073251aea875ca32a7e3c324.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a10ab7347855f01b71d829cd0caa6a1',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/642f8e9ccc8f449aebdb30811e52e909.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e74bc7b7844b4d9b30a7892aaab4373',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/e60401e84b2398c62b17e646359c07df.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ef8e59fea7cf3f459d163a8fbcedcf0',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/829b910772d2a219351bafb85e3f0da8.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f9411d612c81eee443113bff597863b',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/a2efc0f529fadf14d60ad7f0674d9427.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b83c6b6717eef7f254bf4f797cd5d66a',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/e87590d6693fa4a992f6e25ae52d2bf3.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9664b20e37daddd1f3444412aa7bdf33',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/3e7cd39ad6d9a0fec78107ba9fff89e5.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a45ae07e09f688a90fdf7b8ef534e51',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/f71f3947e8821b6a62d3b0c2d8b1e306.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16bc5b40cfac5dc6e3da4472033fb1e3',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/6082773955765a8f525dfee0334d8d0f.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccab5f86a10bd3a441f56034879d0cc9',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/cc54a5fc98704a3e8084667fc15957e7.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75d7328738edb753b1fb976f59d52a00',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/322c277e8f4c93efa0cf0f3b8e72d33a.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0624e51afb8abda2cf3b42ba6c76abfc',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/3e22fd0036de25b22ce23ed747e28fde.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a81b1b1a79d0e72f43395390c321c598',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/fb73718dad01fd4ce0b846b53d56d54b.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1348b16c7db5d2816fef03e50a905221',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/7226e6dab644a3aaefa918bd10f34bb6.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43cfcea98746389a99faa3620b9c98e5',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/d2bb6ef83efad2d85ce4fd6248a3bf0b.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dc66bc50433350289b92a8505933476',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/f9397cc6d6372cfae3a9f0c75e428ba9.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f346c2b94b48da5cfa4fd8385ccc2879',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/cfc3a8c93f622094500619ddd54cea36.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1b95d20867fdf9f01492d7488db1bc9',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/64acc7d580d96282d58f149c2b7bd298.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27e2103218a68cfc4f78b572dcd05f7b',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/021771f5568a8158a98d2b9b5f267859.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0142be12570765092d2ab2bfc3497ea3',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/6878454970e634236aaeddd1afe9625b.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4408a4a3e8fbbeea96905dd310e0fcf',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/90c26fe4d814df7901f35df04dae3617.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b12bb4415d9fb7c05a486ae2bded2f3d',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/c223053743b3190f5887454be9d2f859.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '697ee325a14bf225644a3cd46cc217b5',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/f0b0ea838e95bf20290aeef33ed3fb93.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1132574ef243b0d2ff899eb2abf0d1bd',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/156b9cd2e5ea7c6929932f36b2490ee8.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d2421db6551b2826822c54c9290c5b2',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/2c6659cda2a9a84ce381aaac5baadc6a.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2b8dd6c1e8842b27ef2c74244999bfa',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/4da1c6ffb7deed904f574b5cc304da5a.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb5dfaa8d7cb6c2f20416cf4f8d1ccc7',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/eaeceedd123197eb6e037d619f4f69be.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52adf03b6bcd0f728beffb8e320cde00',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/2c47fd191aabc86d93456e8f06873fab.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7d0a3857d6c0b654ba4ac935c984c0a',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/fb2b1c1a1b24233cd4440ca97b14c705.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '508c58ee712b47ccc0253525bb75f179',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/d1697bcb03d3f4a95cf5ad45d0e53b7b.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ead398086484336e48490d3fd5f6810',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/30dda0d8a0a252f3ade9c9f6f897afcf.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf93853a1d4f50a4fff898cc9c6aac5b',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/4b334c290f0f306f8cf5d4a00fcda0a6.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39e6dfa857af693dcd604cc5ab98377b',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/52ee800435eebb1952cf462efb663a2a.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6e2e6cb4e88a1479e12a9fe4988e729',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/e453ee940216ece2f259ef98293e188c.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '752bcedc4b7b3b10d0e709d04b4a5a93',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/5b9d1308a61ea02d2dde3234257eef8e.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '876990a19a65e8e82c3dd8035192ba8f',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/1d14d2025f603cef81c968a4d5e5a04e.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '506238f8a3a4b27c644be85df9bd144f',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/cb38a7b73af98ed120f585f37398ada8.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6a5ef8c8fcfc61665525efc40c01d39',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/48749877ca7fb3e1bf45fee909f5260c.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72310d52038da2d736264086cd8f2687',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/d81a5483fdb4e3a2d93d989f57f7e585.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e7ae78dba2ce710b1a82dec5a0aff22',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/9cdae9275ff499a59799ad72460f0ea3.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daf394c721fe9721bed87508ba279db7',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/5f7d602cafb80169ebd5c4cebdb54cca.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dafec6e013539116176ebf500d67fc88',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/03c78c701415286eb93d3d4c4de52014.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5ac1d1d23bfadfc1ab0093e865a5d0e',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/bcd3016dd04c7bf9e3ca5951ce36c788.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4aee90e75508e9cdcd9192deeb41aba0',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/af4ea85250dec5306686182ec469bada.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66cfacce11c02f0deadcfd014ccc5479',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/5128bb4086c72aa425347295b5f845a3.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46b860577dcc764db9b2585137454ba3',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/8ce45ff883d16ce063cdcbccde6cb893.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d1a4cb8b612dfbc59acfebf16b754a0',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/20bc0c812003aff0ba672c7ed1428f02.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae8acc0a4f4503f1aac9f12ea5cd4687',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/120e391ebdbc9e45df84ad890a700ef4.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8a50a40f184f7ab733c200cca5fea7e',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/df5252e4489b5d420cf7ae7476ee2745.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eed232aa6b64a0a9cb0fb5da94cbc423',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/52e09237ad2d09b4e54ff796a3e03643.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '414f718dea659125c137f702a57c2858',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/66c92e59b163525f067e7aee52deada7.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fadec65e39dffe20f38ece1810669217',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/22b2f8738c888ce06a13685a35760a3b.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd824050d7c505ac65b3e90672f33b3f7',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/acfcf34a6ec5623bcc9392e7e111e69f.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '252116aaa2f80153fba42bdc0d5285d3',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/86a22d510c88dcb1d0fda3cfa6b8aafc.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e087be3c42e5b49ae684ddf2ec7185fe',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/057276c8490574eff25ff2b32b3d29af.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf45a43e4964f462b9d5af797f7b95aa',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/75725d0f5f854f4acce8a832a355d0b8.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01df9c558db7e1b664e347d5a3cec3fd',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/607a228563d3e8df5e4ecc07bc3c3256.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6aa7ab8e1facdcf1cbd8489c7d32053d',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/1eed49946a6711c58eadda9fb12c03ee.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77764d836cedf91bf503e5e27e6faf20',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/1dcc8033f323d6dadb63fd9c61fb5f3c.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fdaaf40e29190c681098ccb5218f17c',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/98f56697dddf557e36ad5b1df4282ae3.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e7d9015c814ab9c4c51ade49b2ef435',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/42f02c6ea58970f740933c4171a788f8.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3c32222b452c00b75c8e42d42fd6aeb',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/0e3b94351fe213749bb56478a29b7565.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9e100020b5edd3d7e7d4fa23739b8e7',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/1586aafe0a6d57067c61ad39fff6faf4.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55888cb91293ab5335e9f0fd8040b5e3',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/ccdea68deadb37db7e8b4f68551051b2.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f2c21e817a1a0bbec001e75cf20b2b8',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/2e2e1325c8f2fbd392e4e91a6a3d420e.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb577a1e6fe54495be9b10ab94397a29',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/5132dbf09fefde1bb132746a1dbcf92f.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '335ffaa6039e5cf55ce11079bae641c2',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/56dc26a0e5092294d521955401f79df8.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0aafde905549d8459cbf86a03e3424f1',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/07ce356ec80d75a0b35571f657917a91.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df5a3aa0d3c8259bf9c9d5abb01a25e9',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/dcdb061048b996fdddab1c0eb483bcef.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed6df667183c5cbccad35da285a5b8a7',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/d90c89f7ff5fdfff8f15ff735baf84cb.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a29d9bf9e3df86664d972b818e2c8897',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/1a20aab1c2fca7c4ba52421dff97bff1.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05b577192a2cbc0939f4adf605519549',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/cb16a78dc5a6f1f7557bec39f56a82f7.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29e1e8715836badb790bdb15ba6fa7c8',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/69866a7ebf7ded9048ebfc22a8ea4e0c.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68d5594ceb4657e88552eb6b88f44bb3',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/0c191afee5bbee71f69188d5a32bb873.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f2c8d8c764f9d2e0b43a3e5277a6428',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/05d3edccef1945ee1e23ca1805d9a5a8.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86e6d2b1c8537a52a2af2d1196e601f1',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/5d89a38935e41692d8b056285758e337.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db4f3a9d42f64b35ea7edfba69006062',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/9c4fd9767d81dbd90d5fa176772ca667.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fd78473d910440d4e479d67edc28128',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/14111b252d7f838d49367b14c5be7657.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '712a3843f0ef709c957314f960d80a73',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/68f79f0c4e889e5fa5bc1a2a8f71b603.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd093c66f786d36e7babcc687c44d42e',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/84e3cadc6dd0f693b894081a6d72e594.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3f15cbdeea5033fcde015e7e121ba06',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/244e6384ddbdf2d8f71ce8122c597527.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d485a7164dd759c5fb28def0fd76c57',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/ffac1772098ae872138fe942d4b17d7e.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62e528308ddb9387fe6fce8bcef5f3b1',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/08717426344fb25be7793fa6af07e134.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebb45b2f3c3e08466839d001f71ce576',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/2d17c46edab68fa1c0b3ef984d076d8b.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f64701b2fd50d6fc2ea66915f8fdbb6',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/fcbb330651549b15ab622558e7d92b28.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '186e58b6cb0ae4cd7c28a7d41c374913',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/3b8c90d862b91b95d232c0dab9b91ae8.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3098ffdcea378178bc811a733461b13',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/a1b8d85a1af70daf50ef56037d6f9140.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd40594500ab374817844ab606e82efb',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/55a723885a551ea34d4c8af14560b1ec.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa3c912ee57920d6b43b7b746cdea544',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/f41f73749dff99eef117cdd41c267be8.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6de283412f01458a5b1009f60e209887',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/e58dd4db1a7da80aa9660600a6049e3f.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ab450014058bea06908694c789a7197',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/c153728f27574673c484c7aa91d1a47a.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1fa500383f36b6cc9ad3b802085cf11',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/7dcee48770951628fed8026c50ea6c0a.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51e29baebf1b9bec2543de56766142fe',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/57baed087bfb21af63f28b3f01760f26.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c0b3154b2794e833320a8a7c5e858b5',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/a264372ff1c770eccac9840c83577ed6.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '764e70aa28f7942c7ac1225b7d5a0d9f',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/039e6f805eae03eea9792838e12c88be.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cff8e8f22bdac6003ac4b28f9a423224',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/e9d7e19812d80109300501a817a76f7a.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc958c57f099a36dac091311d64bcee2',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/1e75d7b96c9b85364b93de6b6d1b53d3.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '766de3ba2ebfd2a3fc7792c9fe403fa6',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/5f2e22865058ae234b53948ebbac7e84.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ef2e58862dd1abc96d5143f8e66c2dc',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/b32245ea164aee7cdfd15485d16a56ce.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce8e4f5bea5eec649646067b3f344827',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/eeb170fb0b41b165732325a85b8a0c49.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db18e35c9539572766175429ef467752',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/8f40c33dedd41e50208601a3458912fc.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf9b78dd3b4b084cc102822e719c46d0',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/8e1c890f4f1faa1637c0ab34b180e5b1.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06121dc8cc970512aa143657a4ea7974',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/20bb09d2b18464923ecd6c9febee5b15.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbeb02c0609d9f936504ba7d9cda406a',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/b2d5a039e94f5263f65883491e936d84.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '223e6accde9b9e80ea6d90c7e041a35f',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/166d46424aea833687ef28d4213ca7d8.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '788f5353303d555500050bcd44fdb3d9',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/d6e5725c38a5da44860b3219d1031868.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c72df87c2c69c933440f3371cc14fee8',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/387ea7d0b169ac273df3b81a0d08d6d8.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f315f8e95cc7e165c4727357c0912d8f',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/2179b7e1ce393193bce1b504f5424401.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '375ac62d19a8fbc9975ea4a59ca934f5',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/fc9f0ac1b6981e4d13e2690f068c535b.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '287e696c70ec271b021e76236907a91f',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/4ceeddcd85d0fe1f1e941b6b53ab4072.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cfe5fd8bd7387da71ab6cbde5e81d06',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/a92fec1546fac4d5fc3fc7bc40aabe83.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21c5ba3ea888d5743500a4e3dd85d6b7',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/ddc5af324a34830e5dba00a89103aafd.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9831322a9a641ea4578d25cc7cfbba45',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/feee260fdcf0256c6ab808b36e46256c.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd859a8591b291c24c306bcee332c884a',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/b3d501b72566adba2edea002a847de40.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '507e7f9cb3bcca9b7330d034152470ad',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/0d07bcbc15ebec66f6837bbfd79c17a9.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '401a3790112272014205e527f190dc4b',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/7bf5f977ebd61186084b7690288d828d.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4553a8fc3441e4e7c485882584edf590',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/930c79236d9aba12c335c6363b4f7ce8.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3731012ad5192ad6d66b0b11be3f631f',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/639ab4ea476b28cca590b6530068fd28.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9167446ca081d0cfa7e5495aa64ef3f1',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/f9add5b89e30b65c3b6055b7b7711668.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1404e6c3e2e021969d8396cf7cf7543b',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/08fa5c75503bb7f1705e0a7d1591c7ac.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a96602bddcb28951d12019b1caea78d7',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/df6e872f539c3650144b8a9c71b755dc.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32e9fae034d93da677ba98fa0e184f61',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/f2caa096e1f1bff3a03630175de2832d.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '415b537bec0ef1449a83711f734fde64',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/f1e37b7d91f6008464d40ccc959171f2.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba613bcd096e23018a127126ccf253fa',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/d0fbbdfcc0ad4cf54639c00293f24b11.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '436d42218c1864a0b3ae421df5eef508',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/7abf1a3566257599d5f6ebf2bae9168b.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32359a1702b970f12f87a8fd315bd537',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/2e4030416d19362a4c16e418af7337ff.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '190ef4802efdf95de1cbc6279db25e8c',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/ca79f094fde633f516f3e36d45728572.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5db84c7aade7dc07ac1fa991d53989a3',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/ed1ed27e49020d01ae180f8608a9a275.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9a8157195593983fb07aa30bd7bb700',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/a23200be8d5402304d3fa854233de554.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2ac0729422f4cba060a096ff4313efc',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/80e19ac4c9cf5521e7c84a0bd5d96bbf.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a5e89cba66073a5201b42d112fcb725',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/a3716787be54ee25e9e7bfe37a5d2f00.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12e90f8fa2f54e2a64d301f1551bb16a',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/3a64738e15e24b4578fe1812d02a7555.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0306bc2bc7e83b625bd3839e68650dc8',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/19d1fc3b8574094293ee4d447232ff2e.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cef200a0a8046d121f48e212bb67ce78',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/e9e7615d71a7c77acb9c7e8dbb425b2f.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4243f241c4cab4ca18c8a4d8cafbfdf3',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/9b13a28e6fae5f852f01fb6bbcff8de5.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16f77dccb9ea19456a1b057d3edff638',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/14336f2e96cc16122c56653dba08d676.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5af9aabd0df93971dddc05765dc35271',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/041dccb1af18e66763ff9bb5237197e8.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70156611712a12301ac7667c239ef0aa',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/e2ee38db0794a39a618b784ecc2f2c3d.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9c4b5577b6927659f7511af51eb0357',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/243ce6b0e55a34b51b789af51aa6c939.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46eb55652f27c089ea80ad651c538695',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/a4a0c66e56954ee808a2365a90c11e38.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f78536d1ead4b2022d87231463b9ac0',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/9d4692bd6c292ac8d1ecce29c9a68931.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31fbeb8987135e0f79d3081f328def02',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/71f6f2a6a640c4f40544f20c94b3b8db.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac1ad17673b6a67e136afd19f481ae13',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/50f93fa38de2dd27d14dd7371bab341c.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f50c118726cbe116e2844deab44f199',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/23c0027c4e8594c1e22b903a4ff41ead.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5108de46f1fa91c676329f549edf416c',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/030fe8d5de5a659f0ab2d95a66d07c74.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a59fe6db5e15062f23f443b87907ee8',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/ece96643012e087ee0608eb58cce87dc.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd50ce4595007c4c3da16187f3d112a9b',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/c846516d3690726d3af20ee420545f45.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dff047c1e2b8dfb8e3ec5995fef4cba',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/bbec467cec066ae96a138372a5e59d7b.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49fdb07e646ab50785518bddcb62aef5',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/f5c4a2a5a0da586937bc9632a15db2c8.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d3384e66afd5941924d1a0eaa83d361',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/422407c5e618480b062d6023943c31a7.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '611598c73809b085350ee3729562f105',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/94a1a5d20f2f346a593e33239ecf4d50.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b6406a5264365c185b0b1e52ca2a4bb',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/1d05e542de20379e98a56d2dbe26e887.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1eeb8fe87c444461eb6a18096c1fd06',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/ef3649bce1d1bc9c5a7748e899e2a2cf.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f90b049dc628e2a60d7bec28c8c9dc5',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/7163aa83a54258bf67850ca5988c68b2.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7231e3eaef8b1e19303008944599677',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/67768968f31d405044033059d884de10.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ee80ab7a314a4f14c5b5d62cd06c575',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/d2738d4098d0886a24c65810245e9a72.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '816810f6bf508329453c4d9d14968b0b',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/0ce926eb03c0af7659695c486457f72b.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '227e08b0987943fcc057a111130ac7c8',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/26d398c1cebca57aca7cd4b4e0d82caf.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bb9bf9d729ebcef3306d7b6132872fe',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/908720549a52ea51058c3a426d0f8cb1.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d207387f886c0bae352373fefde6db8',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/b5a3aaa89cc3a5e67ce1942475426c0b.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b4020c2c45725c927ff0ee1642e9d52',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/a4df3dc0836c98171d2ffe49f8a052f3.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6df43802e74b5c4a0d7827e5959e3a66',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/58487575fefdff6d201269f6e6db216d.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c13cd3b8d1e8c010f9ece17ec48e459e',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/9dfdb18e0286dd3641950a4d71fcb8a4.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa9ffe857968ed889b5b2dd50605a8bf',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/84e2c8a0deb2245ed772b8cd905860d3.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f7c095c38aa5c507febb45522039878',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/29c26341d0d4354df28f5e41940dbe8e.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bed02e3b582256344e35ee68c0158e3d',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/0e16f1d67cb2e970e88acafc25ce1083.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a954c818be59b985631bc37ccd862f9',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/f8b439acbce04c7ef73d6cfdfbcdd241.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0e49a6848eeb20e60d6c9c0cb694ed9',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/43d382ca752c7db58baf3021a9dfcd01.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5250b4a7fe38e8c2d407be8512f2ce85',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/5a131f8492c4f00dcc2ca4bcb2eca90d.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '074f4a2f4af0ef3a1e730bd077d7a835',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/78f1bfaf9b0330a2cfc1b49afcede1d6.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9449eec9358d0b40c72a5c1ba029b125',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/bf04f55792566d95cbcd9bb6b0212c2c.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee1a681e2019186e25950eb084c62214',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/955c2b95d24700a4af610c5cb5de029c.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83f21bb8159b75fa7bf86a942fce62bb',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/caaea03f7937ffd452701d650a7e0e6d.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f465def3495dc94f8b873ce24783ff7',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/58614653ad26387c615426876501752c.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd148011e83f16215b63c2beb0f0ae703',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/b9b21b706aff17cf0177f6412b2a9157.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f1bd585924e49867312ae4b397903b0',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/ebe5917736ec13ed6b687f4e3dc0caf0.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2e077b067ebd1a19a0aeb17a760b3f5',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/0143d20af95767058280d063064b67ed.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e52633e5333a0bc33b1602f080e0205',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/8d3c5b268eefa315c3e03aa9b7924f83.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1e9322f5db3322dcbcfb6e9fe661800',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/1ab1f680ee563b19082b50edbc038da1.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f24a4a00e1b85de79b908af6253408aa',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/274dad9f07eb7382646fc50e9933e1bd.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cc6d9fe576329822e2aaddb11a8c037',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/3e1b236e20c156aa2327253a0e309a23.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f4f5c0223b12c1e83db4185e49fef0c',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/63c456e90f605773d973ffc4e8910e83.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa45925636161080804596df2a82f59f',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/a9f92e8a3f4f758aac201d0a01d0dad5.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62d3e2a601708d525132fa871f8ebaf5',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/e4ae491f78a1d694e0978f39f423ac61.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f9c02129a69ac45544543c282e28e4e',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/fe0f518e18b9bfbd06ef8cc9b62284fc.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7370bb7720042ffbb6484c62956d7fbd',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/1df7513cdc2ff886f55f178e07a66d21.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '154a09dc1dd99ca733842cc5bf1af909',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/c4f496da3757b16de5f4a4ae289cbba3.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3536b5b23bc50af6d43ffcd92e5897d0',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/81903333298bdc399a6b7081a167493b.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a6924dce2026b0e95ea0ebbb67f8253',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/9170ead09cf31a19da72fb7ef5f71115.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96b91303ab7c707f503a0e7644c14fbd',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/aa78d82b8588e685279c7bc2068410f2.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '473c5ef75220e069838132193407da73',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/2ceb93a3025fbc00b922dd2af7612361.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46c5c59cc1625a0aeb8b2e059f3652bd',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/58b4a224b2749f1d850f2e714ba1a737.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f378a0743161a58bc5a774d239d906ed',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/f3c8eaaaa6fe92821ab2269c222b15ff.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae7ab18179c59311c5aa37517cc23f39',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/86145d96d96a508271b20321652e02e6.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '150898e30aae145694d930f4125abe41',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/0837234398ec4302efc9e7a67df045bc.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6000c358d9690ff86e9387199981cc19',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/9082a62cac45c3d34be2c2474107a4a7.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71612c08fadfc3e1bed9ee6f1e82c40f',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/276a134285894ca8b2dd31ce482041dd.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58eb63e9eefeb2ea659ae593d2ad5282',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/89e5529e7987f05be573f0c60c1a750a.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24e6bd11c66561f3fc43fd1a3a992dd8',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/ff7c6993026da320a8d623323007ca9e.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '616ff488dd3a46c79dea02a095e043bb',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/6a760e9087a948521bb08acef06e4edd.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8275f7f801790a1dabfa71859ba84622',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/1b33447ba190ef8d83e4e9b50b3a1a0a.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcc062dee92b1a304fe694b597eddbc5',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/ec06138841f981122531dadc77a14f9a.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dfa737f3e42be019cfdb3aad2e227a4',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/2324bdc5a5e97e213f2c40fc5e726011.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35d1f56d910a16908eb6e05d3aedba2f',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/4dec8af699c800e2b8c12c615fad79fd.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0883784f268761d9a32a4ad6f9c1443b',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/1c95756c40a4d56364e7c87563dcc05d.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af4136f9070b2c74f054edbad59b8d9a',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/eee68f2144f17d0e6488c2260bf47676.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeb4d4f547402acbab492650d3542f56',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/422ae9b9aa0ac08e084360709b527a28.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c70fb78dcfa9bdfb9a44d2e0059d465',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/4c840fce537a5d5546199f68c32f1bea.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa313ada3c7f544fff1675d90aa8a683',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/7dc241daefc77f4c62b59caaaf28c498.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5afc22472f828fcd52796d7c815e55ac',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/66c410986786bb82b4a2ba7b737bb899.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1edab43bbafd8c36cdae06203c854be0',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/fbf68b23854cdb60dba697286969c8ba.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1178d7a0b6362e7433d2bcfe5a697ce8',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/4557710a4f3c29a3013605cc052860c4.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fca8c9e6c03de4c92715bceacde046cf',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/fe03564a56547841df5030045514e967.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97b9cfda5bf5c81c6399bb49186bfc23',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/6b2d6dc09588c841a843437509b3f278.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '194172de5e6cba280ac858c002f8b2e2',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/bfc3847a14b39aee7484185850fad877.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e7a87f21e63816014c79a90f754549b',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/3cea075c3261dcf9aabf773016183c58.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '50aeb0776b56d6b59d550a7778654d41',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/81d299adcf13d44b2115a1a8bb0e65e4.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '6ed205a07faa2b60eea58632dfebf5ed',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/d5956719440c754cb74bd21af54a8b7b.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'ea73eecc1788673ee9c21a3e269534cd',
      'native_key' => 1,
      'filename' => 'modUserGroup/465009f2564387e2e5d001c753e200a9.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'c7133f54e7c50ebe74513f1e8bd51ec8',
      'native_key' => 1,
      'filename' => 'modDashboard/aa062d49aad7cfa717e82bd396da5ffe.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '5814cc9e80785b5396ea1f9a74f9d934',
      'native_key' => 1,
      'filename' => 'modMediaSource/4234f10562a4d927674a8cd1faa02ea8.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '5f01c8b09883b361fe9f678c1fc9a341',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/41c78ac470e7cffca17eac2b41c7437f.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '78d0dc8446a0c0e368a92f5e70cb31b1',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4f117abf6053158a137b7d7e34c5d0a0.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd752c262470ecc055cafef2294892fa4',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/8bef80c5bd4b846d2fd7164ef2f718b0.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '6ee179cdd2cfb1c921f0586e8eee188f',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ff310eb280f37e379a45451a57a42218.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '04bda3e6e485e7845eb5f0b19d2e3ef6',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d2c4be2d37638465990ee81ddf3bf0fa.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '3db800c9f54f753a6a09a5f8dbbd798b',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/30ab769cddc6a95e2e7d15aa2d4d1b57.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'abad39bc8ee8aff8011d890dbe7db29b',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/aeb8b74b091f8f58a6fa581c48a2a8b3.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0e41c4c185d52caf1bb105655e835a67',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/219631dc276db8b264a01321c593ec62.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ace8b750fbdc0f703a4ab8741f788527',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/8bf309ade6434e098c741de8cea93502.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '47bfc1c99033bff3c5d45009e10ca496',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f6497f7ec314c6f497339670c96b3da4.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '78ad0f081b348d990d2c5eb36df2fe4d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3de55e9137a28be0ba5ae0912dec42ab.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '1d23908b27b786b4a7828a85d6af3265',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/dfae989318d5cda6cde7d076522006f9.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9ef239f5c448d0787cb491ecbddad4dd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/431e65970e46ae5e29752ecbb2b0a99d.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '1ba5ebd6e0298d1c975d3e87901a1a21',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ca2f38881320f92bee4b873e848d3c98.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '65f14c3bd783ce38e0c5b82779f48ad5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e6a7405b8ddca05185951620321979f8.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '117fd2e2e8f9e3d0b9429fc298efaa9f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/4d01969623ebce26e76875cdcfe8e859.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a3b94afa272588e2aaf57e9d76035b24',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/05df4b11c70ac788fad0f34609cdc292.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8e029962cb8a6b3aa70db987754f0c80',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/feefa3c76adcb7d3a279c7e981e5a261.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5c277511ad6ba50c312d3e10ebbbc1dd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/9e87108ae0325b25a4eddc8fb70aec63.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5c17d1d52b19997527de1117a995e561',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ab5eb8c4d30b3ffd4c95da28b6724d68.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0ad96cbbb88b9ecb5dce27ea6fe1aa94',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/542f9e6eafea1cf1943f4734f12aeb04.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4095f24319ad80392d203426e856cd1b',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/492d18a07d0eb7338cb7afcf60ad1514.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9a1768dd10d446ae930d2ac9f3912567',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/bb3b24507626c62fa34872ccff06b7ae.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1bc87a7d4c71a19598739784020ca240',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/57fc03c4a4649542cf0232ca0fb01d69.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c4795911854b4322af71bec1365ffab9',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/70c87a1401fe047469d184529412a971.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'abfedf7445184478efd910f75be05631',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/4cb5b083d82937500622e094e51f5142.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ff355e84614ff390300cf6fff838e863',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/96ae7030374016d2e632ea5466e8f57c.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9dd7d64dcd53bad671f2f63e2fb1fe40',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/39709fae7e2839ba100223d57ab7984a.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5a11ba326348e09cf9ccf2084429372a',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/424c1676e238e599d7d3cc1c87ecee5d.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fdddd04b30daf23f333eed352d1f6344',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/067e5760327a291b139ad63d1f83eb52.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'de9ec6277992c40acf05d12285217f13',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/12302e80f32272bbe31cff20994ca953.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a8fbb4bb33e24892c92fe3edec1d604f',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/9f3b18182c09c76ce2331307713d6da4.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '1a845824dddd512ff77f08cbfaa24057',
      'native_key' => 'web',
      'filename' => 'modContext/aabdb146c3eb8abdf5453920a0b40c59.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '2c78165909ddf5765121c9652f5ad433',
      'native_key' => 'mgr',
      'filename' => 'modContext/70fd573cc9a4955529d9bc20237e2791.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '942350f47f59213f142908dea194e96b',
      'native_key' => '942350f47f59213f142908dea194e96b',
      'filename' => 'xPDOFileVehicle/806c13a0f0ad9d2f821a04d8e755b2ef.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd79cf855f874c5406fb67bd1bb5eb9f9',
      'native_key' => 'd79cf855f874c5406fb67bd1bb5eb9f9',
      'filename' => 'xPDOFileVehicle/5e7fbd12a6c0c46fc30a44884b10b425.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b903ea0fb8305ecdb70e4181f0d0b404',
      'native_key' => 'b903ea0fb8305ecdb70e4181f0d0b404',
      'filename' => 'xPDOFileVehicle/f6fd4c19d8a7b63ab2dd01b8b2536ae1.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a29c5497910dc000cf97e0512c4d23ef',
      'native_key' => 'a29c5497910dc000cf97e0512c4d23ef',
      'filename' => 'xPDOFileVehicle/3f9928ff733d985595334cb01ed90758.vehicle',
    ),
  ),
);